from django import forms
from .models import Product


class ProductForm(forms.ModelForm):
    product_id = forms.CharField(disabled=True, required=False)
    class Meta:
        model = Product
        fields = ['name', 'brand', 'unit_price', 'stock_qty', 'image']
        labels = {
            'name': 'Product Name',
            'brand': 'Brand',
            'unit_price': 'Price',
            'stock_qty': 'Stock',
            'image': 'Image',
        }
        widgets = {
            'name': forms.TextInput(attrs={'placeholder': ''}),
            'brand': forms.TextInput(attrs={'placeholder': ''}),
            'unit_price': forms.NumberInput(attrs={'placeholder': ''}),
            'stock_qty': forms.NumberInput(attrs={'placeholder': ''}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.pk:
            self.fields['product_id'].initial = str(self.instance.id)


# from django.contrib.auth.forms import UserCreationForm
# from django.contrib.auth.models import User 
# class RegisterForm(UserCreationForm): 
#     class Meta: 
#         model = User 
#         fields = ['username','password1','password2'] 