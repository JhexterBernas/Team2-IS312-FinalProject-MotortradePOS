from django.urls import path
from . import views

urlpatterns = [
    # Auth
    path('logout/', views.user_logout, name='logout'),
    # path('register/', views.register, name='register'),

    # # POS
    path('pos/', views.pos_view, name='pos'),
    path('pos/checkout/', views.checkout, name='checkout'),
    path('pos/receipt/<str:transaction_no>/', views.receipt_view, name='receipt'),
    path('pos/add-pending/', views.add_pending_transaction, name='add_pending_transaction'),
    path('pos/pending/', views.get_pending_transactions, name='get_pending_transactions'),
    path('pos/load/<str:transaction_no>/', views.load_transaction, name='load_transaction'),
    path('pos/update/<str:transaction_no>/', views.update_pending_transaction, name='update_pending_transaction'),
    path('pos/delete/<str:transaction_no>/', views.delete_pending_transaction, name='delete_pending_transaction'),
    # Inventory
    path('inventory/', views.inventory_view, name='inventory'),
    path('inventory/delete/<uuid:pk>/', views.delete_product, name='delete_product'),
    path('inventory/bulk-delete/', views.bulk_delete_products, name='bulk_delete_products'),

    # Reports
    path('reports/', views.reports_view, name='reports'),
    
    path('', views.user_login, name='login'),
]
