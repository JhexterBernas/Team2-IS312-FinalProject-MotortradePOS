from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.contrib.auth import login, logout 
from MotortradeSystem.forms import ProductForm
from .models import Product, Transaction, TransactionItem
from django.db.models import Sum
import json
from django.contrib.auth.decorators import login_required 
from django.contrib.auth.forms import AuthenticationForm 


# Create your views here.
@login_required
def inventory_view(request):
    products = Product.objects.all()
    if request.method == 'POST':
        product_id = request.POST.get('id')
        if product_id:  # edit form
            product = Product.objects.get(id=product_id)
            form = ProductForm(request.POST, request.FILES, instance=product)
        else:  # add form
            form = ProductForm(request.POST, request.FILES)

        # save sa database
        if form.is_valid():
            saved_product = form.save()
            if product_id:
                TransactionItem.objects.filter(product=saved_product).update(
                    product_name=saved_product.name,
                    product_brand=saved_product.brand,
                )
            return redirect('inventory')
    else:
        
        form = ProductForm()

    return render(request, 'inventory.html', {
        'products': products,
        'form': form
    })


@login_required
def delete_product(request, pk):
    product = Product.objects.get(pk=pk)
    product.delete()
    print(request.POST)  # para ala error sa vscode
    return redirect('inventory')
 
 
@login_required
def pos_view(request):
    products = Product.objects.filter(stock_qty__gt=0)
    incomplete_transactions = Transaction.objects.filter(is_completed=False)
    return render(request, 'pos.html', {
        'products': products,
        'incomplete_transactions': incomplete_transactions,
    })

 
@login_required
def bulk_delete_products(request):
    if request.method == 'POST':
        ids = request.POST.getlist('selected_ids')
        if ids:
            Product.objects.filter(id__in=ids).delete()
    return redirect('inventory')


def user_logout(request): 
    logout(request) 
    return redirect('login') 


@login_required
def reports_view(request):
    # Filter by date range if provided
    date_from = request.GET.get('date_from')
    date_to = request.GET.get('date_to')
 
    transactions = Transaction.objects.all()
    if date_from:
        transactions = transactions.filter(created_at__date__gte=date_from)
    if date_to:
        transactions = transactions.filter(created_at__date__lte=date_to)
 
    # Summary stats
    total_revenue = transactions.aggregate(total=Sum('total_amount'))['total'] or 0
    total_orders = transactions.count()
 
    # Units sold per product (for pie chart)
    top_products = (
        TransactionItem.objects
        .filter(transaction__in=transactions)
        .values('product__name')
        .annotate(units_sold=Sum('quantity'), revenue=Sum('line_total'))
        .order_by('-units_sold')[:5]
    )
 
    # Revenue by day (for line chart)
    daily_revenue = (
        transactions
        .values('created_at__date')
        .annotate(total=Sum('total_amount'))
        .order_by('created_at__date')
    )
 
    # Transaction history rows
    history = (
        TransactionItem.objects
        .filter(transaction__in=transactions)
        .select_related('transaction', 'product')
        .order_by('-transaction__created_at')
    )
 
    return render(request, 'reports.html', {
        'total_revenue': total_revenue,
        'total_orders': total_orders,
        'top_products': list(top_products),
        'daily_revenue': list(daily_revenue),
        'history': history,
        'date_from': date_from,
        'date_to': date_to,
    })

    
@login_required
def receipt_view(request, transaction_no):
    transaction = Transaction.objects.get(transaction_no=transaction_no)
    items = transaction.items.select_related('product').all()
    subtotal = sum(item.line_total for item in items)
    tax = round(subtotal * 0.12, 2)
    return render(request, 'receipt.html', {
        'transaction': transaction,
        'items': items,
        'subtotal': subtotal,
        'tax': tax,
    })


@login_required
def checkout(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'POST required'}, status=405)
 
    try:
        data = json.loads(request.body)
        items = data.get('items', [])
        pending_txn_no = data.get('pending_txn_no');
        if not items:
            return JsonResponse({'error': 'No items provided'}, status=400)
 
        # Validate stock before saving anything
        for item in items:
            product = Product.objects.get(id=item['product_id'])
            if product.stock_qty < item['quantity']:
                return JsonResponse(
                    {'error': f'Insufficient stock for {product.name}'},
                    status=400
                )
 
        # Create transaction
        if pending_txn_no:
            transaction = Transaction.objects.get(transaction_no=pending_txn_no, is_completed=False)
        else:
            transaction = Transaction.objects.create(
                total_amount=0
            )
 
        total = 0
        for item in items:
            product = Product.objects.get(id=item['product_id'])
            qty = item['quantity']
            unit_price = item['unit_price']
            line_total = qty * unit_price
 
            TransactionItem.objects.create(
                transaction=transaction,
                product=product,
                product_name=product.name,
                product_brand=product.brand,
                quantity=qty,
                unit_price=unit_price,
                line_total=line_total
            )
 
            # Decrement stock
            product.stock_qty -= qty
            product.save()
 
            total += line_total
 
        transaction.total_amount = total
        transaction.is_completed = True
        transaction.save()
 
        return JsonResponse({'transaction_no': transaction.transaction_no})
 
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

    
@login_required
def add_pending_transaction(request):
        if request.method == 'POST':
            try:
                data = json.loads(request.body)
                customer_name = data.get('customer_name', '').strip()
                items = data.get('items', [])
        
                if not customer_name:
                    return JsonResponse({'error': 'Customer name is required.'}, status=400)
        
                transaction = Transaction.objects.create(
                    customer_name=customer_name,
                    is_completed=False,
                    total_amount=0,
                )
        
                total = 0
                for item in items:
                    product = Product.objects.get(id=item['product_id'])
                    qty = int(item['quantity'])
                    unit_price = float(item['unit_price'])
                    line_total = qty * unit_price
                    TransactionItem.objects.create(
                        transaction=transaction,
                        product=product,
                        product_name=product.name,
                        product_brand=product.brand,
                        quantity=qty,
                        unit_price=unit_price,
                        line_total=line_total,
                    )
                    total += line_total
        
                transaction.total_amount = total
                transaction.save()
        
                return JsonResponse({
                    'transaction_no': transaction.transaction_no,
                    'customer_name': transaction.customer_name,
                    'total': str(transaction.total_amount),
                })
            except Exception as e:
                return JsonResponse({'error': str(e)}, status=500)
        return JsonResponse({'error': 'POST required.'}, status=405)


@login_required
def get_pending_transactions(request):
    transactions = Transaction.objects.filter(is_completed=False).values(
        'transaction_no', 'customer_name', 'total_amount'
    )
    return JsonResponse({'transactions': list(transactions)})
    print(request.POST)  # para ala error sa vscode


@login_required
def load_transaction(request, transaction_no):
    transaction = Transaction.objects.get(transaction_no=transaction_no, is_completed=False)
    items = [
        {
            'product_id': str(item.product.id),
            'name': item.product.name,
            'unit_price': str(item.unit_price),
            'quantity': item.quantity,
            'image': f'/media/{item.product.image}' if item.product.image else '',
        }
        for item in transaction.items.select_related('product').all()
    ]
    return JsonResponse({
        'transaction_no': transaction.transaction_no,
        'customer_name': transaction.customer_name,
        'items': items,
    })
    print(request.POST)  # para ala error sa vscode

    
@login_required
def update_pending_transaction(request, transaction_no):
    if request.method != 'POST':
        return JsonResponse({'error': 'POST required.'}, status=405)
    try:
        data = json.loads(request.body)
        items = data.get('items', [])
        transaction = Transaction.objects.get(transaction_no=transaction_no, is_completed=False)
 
        # Clear existing items and replace with updated cart
        transaction.items.all().delete()
 
        total = 0
        for item in items:
            product = Product.objects.get(id=item['product_id'])
            qty = int(item['quantity'])
            unit_price = float(item['unit_price'])
            line_total = qty * unit_price
            TransactionItem.objects.create(
                transaction=transaction,
                product=product,
                product_name=product.name,
                product_brand=product.brand,
                quantity=qty,
                unit_price=unit_price,
                line_total=line_total,
            )
            total += line_total
 
        transaction.total_amount = total
        transaction.save()
 
        return JsonResponse({'ok': True, 'total': str(transaction.total_amount)})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

    
@login_required
def delete_pending_transaction(request, transaction_no):
    if request.method != 'POST':
        return JsonResponse({'error': 'POST required.'}, status=405)
    try:
        transaction = Transaction.objects.get(transaction_no=transaction_no, is_completed=False)
        transaction.delete()
        return JsonResponse({'ok': True})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

# def register(request): 
 
#     if request.method == 'POST': 
#         form = RegisterForm(request.POST) 
 
#         if form.is_valid(): 
#             form.save() 
#             return redirect('login') 
 
#     else: 
#         form = RegisterForm() 
 
#     return render(request,'register.html',{'form':form})


def user_login(request): 
    if request.method == 'POST': 
        form = AuthenticationForm(request, data=request.POST) 
 
        if form.is_valid(): 
            user = form.get_user() 
            login(request, user) 
            return redirect('pos') 
 
    else: 
        form = AuthenticationForm() 
 
    return render(request, 'login.html', {'form':form}) 
