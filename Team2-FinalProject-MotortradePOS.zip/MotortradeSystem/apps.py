from django.apps import AppConfig


class MotortradesystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'MotortradeSystem'
