import uuid
from django.core.validators import MinValueValidator
from django.db import models
from django.utils import timezone

# Product 
class Product(models.Model):
    id         = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name       = models.CharField(max_length=255)
    brand      = models.CharField(max_length=100)
    unit_price = models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(0)])
    image      = models.ImageField(upload_to='products/', null=True, blank=True)
    stock_qty  = models.PositiveIntegerField(default=0)
 
    def __str__(self):
        return f"{self.name} ({self.brand})"

# Transaction like ung full cart ng customer na bili niya
class Transaction(models.Model):
    id             = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    transaction_no = models.CharField(max_length=30, unique=True, db_index=True)
    customer_name  = models.CharField(max_length=255, blank=True)
    total_amount   = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    is_completed   = models.BooleanField(default=False)
    created_at     = models.DateTimeField(auto_now_add=True)
 
    def __str__(self):
        return f"TXN-{self.transaction_no} | P{self.total_amount}"
 
    def save(self, *args, **kwargs):
        if not self.transaction_no:
            prefix = timezone.now().strftime('%Y%m%d')
            short  = str(uuid.uuid4()).replace('-', '')[:6].upper()
            self.transaction_no = f"{prefix}-{short}"
        super().save(*args, **kwargs)

# Transaction Item ung each product sa transaction (mga items sa loob ng cart)
class TransactionItem(models.Model):
    transaction = models.ForeignKey(Transaction, on_delete=models.CASCADE, related_name='items')
    product = models.ForeignKey(Product, on_delete=models.SET_NULL, null=True, related_name='sale_items')
    product_name = models.CharField(max_length=255, blank=True) 
    product_brand= models.CharField(max_length=100, blank=True)
    quantity    = models.PositiveIntegerField(validators=[MinValueValidator(1)])
    unit_price  = models.DecimalField(max_digits=10, decimal_places=2)
    line_total  = models.DecimalField(max_digits=12, decimal_places=2)
 
    def __str__(self):
        return f"{self.product.name} x{self.quantity} @ P{self.unit_price}"
 
    def save(self, *args, **kwargs):
        self.line_total = self.unit_price * self.quantity
        super().save(*args, **kwargs)